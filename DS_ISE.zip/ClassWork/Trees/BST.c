#include<stdio.h>
#include<stdlib.h>

struct node{
    int data;
    struct node *left, *right;
}*nr, *a, *b, *root, *old;

void create(){
    root = NULL;
}

void insert(){
    nr = (struct node*)malloc(sizeof(struct node));
    printf("\nEnter the data of the node: ");
    scanf("%d",&nr->data);
    nr->left = nr->right = NULL;
    if(root==NULL){
        root = nr;
    }else{
        a=root;b=root;
        while(a!=NULL){
            b=a;
            if(nr->data<=a->data){
                a = a->left;
            }else{
                a = a->right;
            }
        }
        if(nr->data<=b->data){
            b->left = nr;
        }else{
            b->right = nr;
        }
    }
}

void inorder(struct node *p){
    if(p!=NULL){
        inorder(p->left);
        printf("%d ",p->data);
        inorder(p->right);
    }
}

void preorder(struct node *p){
    if(p!=NULL){
        printf("%d ",p->data);
        preorder(p->left);
        preorder(p->right);
    }
}

void postorder(struct node *p){
    if(p!=NULL){
        postorder(p->left);
        postorder(p->right);
        printf("%d ",p->data);
    }
}

void delete(){
    // a points to the value which is to be deleted
    // b points to the parent node of a
    if(a->left == NULL && a->right == NULL){
        if(a==b){
            root = NULL;
        }else if(b->left==a){
            b->left = NULL;
        }else if(b->right==a){
            b->right = NULL;
        }
    }else if(a->left!=NULL && a->right == NULL){
        if(a==b){
            root = NULL;
        }else if(b->left==a){
            b->left = a->right;
        }else if(b->right==a){
            b->right = a->right;
        }
    }else if(a->left==NULL && a->right!=NULL){
        if(a==b){
            root = NULL;
        }else if(b->left == a){
            b->left = a->left;
        }else if(b->right==a){
            b->right = a->left;
        }
    }else{
        old = a->right;
        while(old->left!=NULL){
            old = old->left;
        }
        old->left = a->left;
        if(a==b){
            root = a->right;
        }else{
            if(b->left == a){
                b->left = a->right;
            }else{
                b->right = a->right;
            }
        }
    }
    free(a);
}

void search(int x){
    a = root;b=root;
    while(a!=NULL && a->data!=x){
        b=a;
        if(x<=a->data){
            a=a->left;
        }else{
            a=a->right;
        }
    }
    if(a==NULL){
        printf("\nNO VALUE FOUND");
    }else{
        printf("\nValue found");
    }
}

void searchDelete(int x){
    a = root;b=root;
    while(a!=NULL && a->data!=x){
        b=a;
        if(x<=a->data){
            a=a->left;
        }else{
            a=a->right;
        }
    }
    if(a==NULL){
        printf("\nNo Value found");
    }else{
        printf("\nValue found and deleted");
        delete();
    }
}

int main(){
    create();
    for(int i =0;i<5;i++){
        insert();
    }
    printf("\n Inorder Sequence: ");
    inorder(root);
    printf("\n");
    printf("\n Preorder Sequence: ");
    preorder(root);
    printf("\n");
    printf("\n Postorder Sequence: ");
    postorder(root);
    printf("\n");
    search(10);
    searchDelete(10);
    search(10);
}