//Infix to postfix is implemented here, other conversions will be implemented later

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Initialise stack
struct Node {
    char x;
    struct Node *next;
} *top = NULL,*newNode,*temp;

// Push to stack
void push(char c) {
    newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode ->x = c;
    if(top==NULL){
        newNode ->next = NULL;
        top = newNode;
    }else{
        newNode->next = top;
        top = newNode;
    }
}

// Pop from stack
char pop() {
    if (top == NULL) return '\0';  // Stack underflow
    temp = top;
    char val = temp->x;
    top = top->next;
    free(temp);
    return val;
}

// Peek top of stack


char peek() {
    if (top == NULL) return '\0';
    return top->x;
}

// Check if stack is empty
int isEmpty() {
    return top == NULL;
}

// Operator precedence
int precedence(char op) {
    switch (op) {
        case '^': return 3;
        case '*': return 2;
        case '/': return 2;
        case '+': return 1;
        case '-': return 1;
        default: return 0;
    }
}

// Convert infix to postfix
void infixToPostfix(char *infix) {
    char postfix[100];
    int j = 0;
    for (int i = 0; i < strlen(infix); i++) {
        char c = infix[i];

        // Operand
        if (isalnum(c)) {
            postfix[j] = c;
            j++;
        }
        // Left parenthesis
        else if (c == '(') {
            push(c);
        }
        // Right parenthesis
        else if (c == ')') {
            while (!isEmpty() && peek() != '(') {
                postfix[j] = pop();
                j++;
            }
            if (!isEmpty()) pop();  // Pop '('
        }
        // Operator 
        else {
            while (!isEmpty() && peek() != '(' && precedence(c) <= precedence(peek())) {
                postfix[j] = pop();
                j++;
            }
            push(c);
        }
    }

    // Pop remaining operators
    while (!isEmpty()) {
        postfix[j] = pop();
        j++;
    }

    postfix[j] = '\0';  // Null-terminate string to terminate string early and prevent printing of garbage value
    printf("Postfix: %s\n", postfix);
}

int main() {
    char infix[100];
    printf("Enter infix expression: ");
    scanf("%s",infix);
    infixToPostfix(infix);
    return 0;
}
