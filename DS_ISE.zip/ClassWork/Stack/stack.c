#include<stdio.h>
#include<stdlib.h>

int i;
// Initialising the stack
struct Student{
    int roll;
    struct Student *next;
}*top,*nr,*temp;

//Creating the stack
void create(){
    top = NULL;
}

//Push in the stack
void push(){
    nr = (struct Student*)malloc(sizeof(struct Student));
    printf("\nEnter the element:- ");
    scanf("%d",&nr->roll);
    if(top==NULL){
        nr->next = NULL;
        top = nr;
    }else{
        nr->next = top;
        top = nr;
    }
}

//Pop the topmost element
void pop(){
    if(top==NULL){
        printf("Stack empty");
    }else{
        temp = top;
        top = top->next;
    }
    free(temp);
}

//Peek or access the top element
int peek(){
    if(top==NULL){
        printf("Empty stack");
        return -1;
    }else{
        printf("\nThe top element is:- %d",top->roll);
        return top->roll;
    }
}

//Displaying the stack
void display(){
    if(top==NULL){
        printf("Empty stack");
    }else{
        temp = top;
        while(temp!=NULL){
            printf("%d ",temp->roll);
            temp = temp->next;
        }
        printf("\n");
    }
}

int main(){
    create();
    for(i=0;i<3;i++){
        push();
    }
    display();
    pop();
    display();
    return 0;
}
