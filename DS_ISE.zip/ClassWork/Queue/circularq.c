#include<stdio.h>
#include<stdlib.h>

struct stud {
    int roll;
    struct stud *next;  
} *nr, *front, *rear, *temp;

int i;

void create() {
    front = NULL;
    rear = NULL;
}

void insert() {
    nr = (struct stud*)malloc(sizeof(struct stud));
    printf("\nEnter number: ");
    scanf("%d", &nr->roll);
    if(rear == NULL) {
        front = nr;
        rear = nr;
        nr->next = front;
    } else {
        nr->next = front;
        rear->next = nr;
        rear = nr;
    }
}

void display() {
    if(front == NULL) {
        printf("\nNo record");
        return;
    }
    temp = front;
    do {
        printf("%d ", temp->roll);
        temp = temp->next;
    } while(temp != front);
    printf("\n");
}

void delete() {
    if(front == NULL) {
        printf("\nEmpty queue");
        return;
    }
    temp = front;
    if(front == rear) {
        front = NULL;
        rear = NULL;
    } else {
        front = front->next;
        rear->next = front;
    }
    free(temp);
}

int main() {
    int choice;
    create();
    for(i=0;i<3;i++){
        insert();
    }
    display();
    delete();
    display();
}
