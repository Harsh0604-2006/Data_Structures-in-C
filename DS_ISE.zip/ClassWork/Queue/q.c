#include<stdio.h>
#include<stdlib.h>

int i;

struct Stud{
    int roll;
    struct Stud *next;
}*nr,*first,*rear,*temp;

void create(){
    first = NULL;
    rear = NULL;
}

void insert(){
    nr = (struct Stud*)malloc(sizeof(struct Stud));
    printf("\nEnter roll no: ");
    scanf("%d",&nr->roll);
    if(rear==NULL){
        nr->next = NULL;
        first = nr;
        rear = nr;
    }else{
        nr->next = NULL;
        rear->next = nr;
        rear = nr;
    }
}

void display(){
    temp = first;
    while(temp!=NULL){
        printf("%d ",temp->roll);
        temp = temp->next;
    }
    printf("\n");
}

void delete(){
    if(first == NULL){
        printf("No record found");
    }else if(first==rear){
        temp = first;
        first = NULL;
        rear = NULL;
    }else{
        temp = first;
        first=first->next;
    }
    free(temp);
}

int main(){
    create();
    for(i=0;i<3;i++){
        insert();
    }
    display();
    delete();
    display();
    return 0;
}
