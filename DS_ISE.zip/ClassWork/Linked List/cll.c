//Circluar Linked list
#include<stdio.h>
#include<stdlib.h>

struct stud{
    int roll;
    struct stud *next;
}*nr,*temp,*first,*last;

void create(){
    first = NULL;
    last = NULL;
}

void insert(){
    nr = (struct stud*)malloc(sizeof(struct stud));
    printf("\nEnter Roll:- ");
    scanf("%d",&nr->roll);
    if(first == NULL){
        first = nr;
        last = nr;
        nr->next = first;
    }else{
        nr->next = first;
        last->next = nr;
        last = nr;
    }
}

void delete_end(){
    if(first == NULL){
        printf("Empty list");
    }else if(first == last){
        temp = first;
        first = NULL;
        last = NULL;
    }else{
        nr = first;
        while(nr->next!=last){
            nr = nr->next;
        }
        temp = last;
        nr->next = first;
        last = nr;
    }
    free(temp);
}

void display(){
    if(first==NULL){
        printf("\nNo record found");
    }else{
        printf("%d ",first->roll);
        temp = first->next;
        while(temp!=first){
            printf("%d ",temp->roll);
            temp = temp->next;
        }
        printf("\n");
    }
}

int main(){
    create();
    insert();
    insert();
    insert();
    display();
    delete_end();
    display();
}