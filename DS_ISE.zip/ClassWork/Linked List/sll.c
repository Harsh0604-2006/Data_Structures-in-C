//Single Linked List

#include<stdio.h>
#include<stdlib.h>
int i;
//Creating the structure
struct Student{
    int roll;
    struct Student* next;
}*newrecord, *first, *last, *temp;

//Creating the linked list
void create(){
    first =NULL;
    last=NULL;
}

//Inserting in the Linked List
void insert_back(){
    newrecord = (struct Student*)malloc(sizeof(struct Student));
    printf("Enter data: ");
    scanf("%d", &newrecord->roll);
    newrecord->next=NULL;

    if(first==NULL){
        first = newrecord;
        last = newrecord;
    }else{
        last->next = newrecord;
        last =newrecord;
    }
    last->next = NULL;
}

//Insert in the beginning of the linked list with an argument
void insert_begin(int a){
    newrecord = (struct Student*)malloc(sizeof(struct Student));
    newrecord -> roll = a;
    newrecord -> next = first;
    first = newrecord;
}

//Insert after an element with two arguments
void insert_after(int a, int b){ // here int a marks the element already in the list and int b marks the new entry
    temp = first;
    while(temp!=NULL){
        if(temp->roll==a){
            newrecord = (struct Student*)malloc(sizeof(struct Student));
            newrecord->roll = b;
            newrecord -> next = temp->next;
            temp->next = newrecord;
            return; // same as break
        }
        temp = temp->next;
    }
    printf("No Record found %d" , a);
}

//Delete after in a linked list
void delete_after(int a){
    newrecord = first;
    while(newrecord!=NULL&&newrecord->roll!=a){
            newrecord=newrecord->next;
    }
    if(newrecord==NULL){
        printf("No Record found %d" , a);
    }else{
        temp = newrecord->next;
        newrecord->next = temp->next;
        free(temp);
    }
}

//Deleting before in a linked list
void delete_before(int a){
    temp = NULL;
    newrecord = first;
    if(first==NULL || first->roll == a){
        printf("No record to delete before %d\n", a);
        return;
    }
    while(newrecord->next != NULL && newrecord->next->next != NULL && newrecord->next->next->roll != a){
            newrecord=newrecord->next;
    }
    if(newrecord ==NULL){
        printf("No record found");
    }else{
        temp = newrecord->next;
        newrecord->next=temp->next;
        temp->next = NULL;
    }
    free(temp);
}

//Display the linked list
void display(){
    newrecord = first;
    while(newrecord!=NULL){
        printf("%d ",newrecord->roll);
        newrecord=newrecord->next;
    }
    printf("\n");
}

int main(){
    create();
    for(i=0;i<3;i++){
        insert_back();
    }
    display();
    printf("\nInserting 45 in the beginning\n");
    insert_begin(45);
    display();
    printf("\nInserting 70 after 20 if found\n");
    insert_after(20,70);
    display();
    printf("\nInserting 70 after 60 if found\n");
    insert_after(60,70);
    printf("\nDeleting after 20 if found\n");
    delete_after(20);
    display();
    printf("\nDeleting before 20 if found\n");
    delete_before(20);
    display();
    return 0;
}

