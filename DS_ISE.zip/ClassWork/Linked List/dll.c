#include<stdio.h>
#include<stdlib.h>

int i,x;

//creating the structure;
struct Student{
    int roll;
    struct Student *next, *prev;
}*nr,*temp,*first,*last;

void create(){
    first = NULL;
    last = NULL;
}

void insert_end(){
    nr = (struct Student*)malloc(sizeof(struct Student));
    printf("\nEnter Roll number\n");
    scanf("%d",&nr->roll);
    if(first ==NULL){
        nr ->prev = NULL;
        nr->next = NULL;
        first = nr;
        last = nr;
    }else{
        nr->next = NULL;
        nr->prev = last;
        last->next = nr;
        last = nr;
    }
}

void insert_front(){
    nr = (struct Student*)malloc(sizeof(struct Student));
    printf("\nEnter Roll number: ");
    scanf("%d",&nr->roll);
    if(first==NULL){
        nr->prev = NULL;
        nr->next = NULL;
        first = nr;
        last = nr;
    }else{
        nr->next = first;
        nr->prev = NULL;
        first->prev=nr;
        first = nr;
    }
}

void insert_after(int a, int b){
    nr = (struct Student*)malloc(sizeof(struct Student));
    nr->roll = b;
    temp = first;
    while(temp->roll!=a||temp!=NULL){
        temp = temp->next;
    }
    if(temp==NULL){
        printf("\nNo Record Found");
    }else{
        nr->next = temp->next;
        nr->prev = temp;
        temp->next->prev = nr;
        temp->next = nr;
    }
}

void insert_before(int a,int b){
    nr = (struct Student*)malloc(sizeof(struct Student));
    nr->roll = b;
    temp = first;
    while(temp->roll!=a||temp!=NULL){
        temp->next = temp;
    }
    if(temp->next==NULL){
        printf("\nNo record");
    }else{
        nr->next = temp;
        nr ->prev = temp->prev;
        temp -> prev ->next = nr;
        temp->prev = nr;
    }
}

void display(){
    if(first==NULL){
        printf("Empty linked list");
    }
    temp = first;
    while(temp!=NULL){
        printf("%d ",temp->roll);
        temp = temp->next;
    }
}

void delete(){
    int x;
    printf("\nEnter the number to be deleted:- ");
    scanf("%d",&x);
    if(first == NULL){
        printf("\nNo record to delete\n");
    }else if(first->roll==x){
        temp=first;
        first->next->prev =  NULL;
        first = first->next;
    }else if(last->roll==x){
        temp = last;
        last->prev->next=NULL;
        last = last->prev;
    }else{
        temp = first;
        while(temp->roll!=x||temp!=NULL){
            temp =temp->next;
        }
        if(temp==NULL){
            printf("No record");
        }else{
            temp->prev->next = temp->next;
            temp->next->prev = temp->prev;
        }
        free(temp);
    }
}
int main(){
    create();
    for(i = 0;i<3;i++){
        insert_front();
    }
    for(i = 0;i<3;i++){
        insert_end();
    }
    display();
    delete();
    display();
}