//Reverse a single linked list

#include<stdio.h>
#include<stdlib.h>
int i;
//Creating the structure
struct Student{
    int roll;
    struct Student* next;
}*newrecord, *first, *last, *temp;

//Creating the linked list
void create(){
    first =NULL;
    last=NULL;
}

//Inserting in the Linked List
void insert_back(){
    newrecord = (struct Student*)malloc(sizeof(struct Student));
    printf("Enter data: ");
    scanf("%d", &newrecord->roll);
    newrecord->next=NULL;

    if(first==NULL){
        first = newrecord;
        last = newrecord;
    }else{
        last->next = newrecord;
        last =newrecord;
    }
}

//Display the linked list
void display(){
    newrecord = first;
    while(newrecord!=NULL){
        printf("%d ",newrecord->roll);
        newrecord=newrecord->next;
    }
    printf("\n");
}

//Reversing the list
void reverse(){
    struct Student *current, *next, *prev, *head;
    head = first;
    prev = NULL;
    current = head;
    while(current!=NULL){
        next = current->next;
        current->next = prev;
        prev = current;
        current = next;
    }
    first = prev;
}

int main(){
    create();
    insert_back();
    insert_back();
    insert_back();
    printf("\nSeedha Linked List:- ");
    display();
    reverse();
    printf("\nUlta Linked List:- ");
    display();
}